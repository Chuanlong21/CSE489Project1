//
// Created by Chuanlong Liu on 2/23/23.
//

#ifndef CSE489PROJECT1_CLIENT_H
#define CSE489PROJECT1_CLIENT_H

#endif //CSE489PROJECT1_CLIENT_H
int c_startUp(char *port);