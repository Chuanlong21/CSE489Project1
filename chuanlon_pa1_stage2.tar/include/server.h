//
// Created by Chuanlong Liu on 2/22/23.
//

#ifndef CSE489PROJECT1_SERVER_H
#define CSE489PROJECT1_SERVER_H

#endif //CSE489PROJECT1_SERVER_H
int s_startUp(char* port);